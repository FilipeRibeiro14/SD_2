Para correr a plataforma deve ter uns certos cuidados:

- Tem que ter presente no computador o Docker Desktop
- Um Terminal que suporte o Spring Boot
- IDE que suporte ficheiros ".java" e ".html"

Instruções para correr a plataforma:

-Em primeiro lugar deve de inicializar o Docker Desktop.

-Segundo lugar, abrir a pasta "code" com o VsCode.

-Terceiro, deve aparecer uma mensagem pop-up no lado inferior direito que diz "Abrir com Container", clicar.

-Quarto, abrir o terminal e colocar o seguinte comando "cd demoJPA+webservices".

-Quinto, colocar o comando "./mvnw spring-boot:run";

-Depois num navegador a sua escolha colocar na barra de pesquisa "http://localhost:8080/".

-Dentro da plataforma irá notar que só é possível fazer o login para tal efeito tem os dados de administrador username: admin password: admin.